/**
 * @file HopDongMenu.cpp
 * Thanh vien phu trach: Trần Đức Anh (B24DCVT021)
 * Hoc phan: Ky thuat lap trinh (KTLT) - PTIT
 */

#include "HopDongMenu.h"
#include "InputHelper.h"
#include "DisplayHelper.h"
#include "Normalized.h"
#include "Date.h"
#include <iostream>

using namespace HopDongMenuChoices;

//hien thi menu quan ly hop dong
void HopDongMenu::showMenu() {
    while (true) {
        std::cout << "\n====================================================================\n"
                  << "                     QUAN LY HOP DONG DANG KY\n"
                  << "====================================================================\n"
                  << "  [" << MENU_ADD << "] Them hop dong moi\n"
                  << "  [" << MENU_LIST << "] Xem danh sach hop dong\n"
                  << "  [" << MENU_SEARCH << "] Tim kiem hop dong\n"
                  << "  [" << MENU_SORT << "] Sap xep danh sach\n"
                  << "  [" << MENU_UPDATE << "] Cap nhat thong tin hop dong\n"
                  << "  [" << MENU_DELETE << "] Xoa hop dong\n"
                  << "  [" << MENU_BACK << "] Quay lai menu chinh\n"
                  << "====================================================================\n";

        int choice = InputHelper::getInt("Nhap lua chon cua ban [0-6]: ", MENU_BACK, MENU_DELETE);
        if (choice == MENU_BACK || std::cin.eof()) {
            break;
        }

        switch (choice) {
            case MENU_ADD:
                themHopDong();
                break;
            case MENU_LIST:
                xemDanhSach();
                break;
            case MENU_SEARCH:
                timKiemHopDong();
                break;
            case MENU_SORT:
                sapXepDanhSach();
                break;
            case MENU_UPDATE:
                capNhatHopDong();
                break;
            case MENU_DELETE:
                xoaHopDong();
                break;
            default:
                break;
        }
    }
}

//them hop dong moi
void HopDongMenu::themHopDong() {
    std::cout << "\n>>> THEM HOP DONG DANG KY MOI <<<\n";
    std::string maHD;
    while (true) {
        maHD = InputHelper::getString("Nhap Ma hop dong (VD: HD0010): ", false);
        if (std::cin.eof()) return;
        maHD = Normalized::toUpper(Normalized::trim(maHD));
        if (store.findById(maHD) != nullptr) {
            std::cout << "  [!] Ma hop dong '" << maHD << "' da ton tai! Vui long nhap ma khac.\n";
            continue;
        }
        break;
    }

    std::string maKH = InputHelper::getString("Nhap Ma khach hang (VD: KH0000001): ", false);
    if (std::cin.eof() || maKH.empty()) return;
    maKH = Normalized::NormalizedCustomerId(maKH);
    //kiem tra ma khach hang ton tai
    if (khachHangStore.findById(maKH) == nullptr) {
        std::cout << "  [!] Ma khach hang '" << maKH << "' khong ton tai trong he thong!\n";
        return;
    }

    std::string sdt = InputHelper::getPhoneNumber("Nhap So dien thoai thue bao da dang ky (phai co san trong he thong): ", false);
    if (std::cin.eof() || sdt.empty()) return;
    //kiem tra so dien thoai thue bao da dang ky
    if (thueBaoStore.findById(sdt) == nullptr) {
        std::cout << "  [!] Thue bao co so '" << sdt << "' chua duoc dang ky tren he thong!\n";
        return;
    }

    std::string maGC = InputHelper::getString("Nhap Ma goi cuoc (VD: GC001, VD149): ", false);
    if (std::cin.eof() || maGC.empty()) return;
    maGC = Normalized::toUpper(Normalized::trim(maGC));
    //kiem tra goi cuoc ton tai
    if (goiCuocStore.findById(maGC) == nullptr) {
        std::cout << "  [!] Goi cuoc '" << maGC << "' khong ton tai trong he thong!\n";
        return;
    }


    std::string ngayDKStr = InputHelper::getString("Nhap Ngay dang ky (DD/MM/YYYY, 'now' hoac '0' de huy): ", false);
    if (ngayDKStr == "0" || std::cin.eof()) {
        std::cout << "[DA HUY] Thao tac them hop dong da duoc huy bo.\n";
        InputHelper::pause();
        return;
    }
    Date ngayDK;
    try {
        ngayDK = Date::parse(ngayDKStr);
    } catch (const std::exception& e) {
        std::cout << "[LOI] " << e.what() << "\n";
        InputHelper::pause();
        return;
    }

    GoiCuoc* gc = goiCuocStore.findById(maGC);
    int chuKy = (gc != nullptr && gc->getChuKyNgay() > 0) ? gc->getChuKyNgay() : 30;
    Date ngayHH = ngayDK.addDays(chuKy);

    std::cout << "Chon Loai hop dong:\n"
              << "  [" << TYPE_CHOICE_PREPAID << "] Tra truoc \n"
              << "  [" << TYPE_CHOICE_POSTPAID << "] Tra sau \n";
    int loaiChoice = InputHelper::getInt("Lua chon [1-2]: ", TYPE_CHOICE_PREPAID, TYPE_CHOICE_POSTPAID);
    if (std::cin.eof()) return;
    std::string loaiHD = (loaiChoice == TYPE_CHOICE_PREPAID) ? HopDongConstants::TYPE_PREPAID : HopDongConstants::TYPE_POSTPAID;

    double gia = InputHelper::getDouble("Nhap Gia tri goi cuoc (VND): ", 0.0);
    if (std::cin.eof()) return;

    try {
        HopDong hd(maHD, maKH, sdt, maGC, ngayDK, ngayHH, loaiHD, HopDongConstants::STATUS_ACTIVE, gia);
        store.add(hd);
        std::cout << "[THANH CONG] Da them hop dong " << maHD << " vao he thong!\n";
    } catch (const AppException& e) {
        std::cout << "[LOI] " << e.what() << "\n";
    }
    InputHelper::pause();
}

//hien thi danh sach hop dong
void HopDongMenu::xemDanhSach() {
    std::cout << "\n>>> DANH SACH HOP DONG DANG KY <<<\n";
    const auto& list = store.getAll();
    if (list.empty()) {
        std::cout << "[THONG BAO] Danh sach hop dong hien dang trong!\n";
        InputHelper::pause();
        return;
    }

    DisplayHelper::printTable(list);
    std::cout << "Tong so: " << list.size() << " hop dong.\n";
    InputHelper::pause();
}

//tim kiem hop dong theo dieu kien
void HopDongMenu::timKiemHopDong() {
    std::cout << "\n>>> TIM KIEM HOP DONG <<<\n"
              << "  [" << SEARCH_BY_ID << "] Tim theo Ma hop dong\n"
              << "  [" << SEARCH_BY_PHONE << "] Tim theo So dien thoai\n"
              << "  [" << SEARCH_BY_CUSTOMER << "] Tim theo Ma khach hang\n"
              << "  [0] Quay lai\n";
    int choice = InputHelper::getInt("Nhap lua chon [0-3]: ", 0, SEARCH_BY_CUSTOMER);
    if (choice == 0) return;

    if (choice == SEARCH_BY_ID) {
        std::string id = InputHelper::getString("Nhap Ma hop dong can tim: ", false);
        if (std::cin.eof()) return;
        id = Normalized::toUpper(Normalized::trim(id));
        HopDong* hd = store.findById(id);
        if (hd == nullptr) {
            std::cout << "[THONG BAO] Khong tim thay hop dong nao co ma: " << id << "\n";
        } else {
            hd->displayHeader();
            hd->displayRow();
            hd->displayDetail();
        }
    } else if (choice == SEARCH_BY_PHONE) {
        std::string sdt = InputHelper::getString("Nhap So dien thoai can tim: ", false);
        auto results = store.filter([&sdt](const HopDong& hd) {
            return hd.getSoDienThoai() == sdt;
        });
        if (results.empty()) {
            std::cout << "[THONG BAO] Khong co hop dong nao gan voi so: " << sdt << "\n";
        } else {
            DisplayHelper::printTable(results);
            std::cout << "Tim thay " << results.size() << " hop dong.\n";
        }
    } else if (choice == SEARCH_BY_CUSTOMER) {
        std::string kh = InputHelper::getString("Nhap Ma khach hang: ", false);
        kh = Normalized::NormalizedCustomerId(kh);
        auto results = store.filter([&kh](const HopDong& hd) {
            return Normalized::NormalizedCustomerId(hd.getMaKhachHang()) == kh;
        });
        if (results.empty()) {
            std::cout << "[THONG BAO] Khong co hop dong nao cua khach hang: " << kh << "\n";
        } else {
            DisplayHelper::printTable(results);
            std::cout << "Tim thay " << results.size() << " hop dong.\n";
        }
    }
    InputHelper::pause();
}

//sap xep danh sach hop dong
void HopDongMenu::sapXepDanhSach() {
    std::cout << "\n>>> SAP XEP DANH SACH HOP DONG <<<\n"
              << "  [" << SORT_BY_DATE_DESC << "] Theo Ngay dang ky (Moi nhat -> Cu nhat)\n"
              << "  [" << SORT_BY_PRICE_DESC << "] Theo Gia tri goi cuoc (Giam dan)\n"
              << "  [" << SORT_BY_ID_ASC << "] Theo Ma hop dong (Tang dan)\n"
              << "  [" << SORT_BY_ID_DESC << "] Theo Ma hop dong (Giam dan)\n"
              << "  [0] Quay lai\n";
    int choice = InputHelper::getInt("Nhap lua chon [0-4]: ", 0, SORT_BY_ID_DESC);
    if (choice == 0) return;

    try {
        if (choice == SORT_BY_DATE_DESC) {
            store.sortAndSave([](const HopDong& a, const HopDong& b) {
                return b.getNgayDangKy() < a.getNgayDangKy();
            });
            std::cout << "[THANH CONG] Da sap xep danh sach theo ngay dang ky giam dan!\n";
        } else if (choice == SORT_BY_PRICE_DESC) {
            store.sortAndSave([](const HopDong& a, const HopDong& b) {
                return a.getGiaTriGoi() > b.getGiaTriGoi();
            });
            std::cout << "[THANH CONG] Da sap xep danh sach theo gia tri goi cuoc giam dan!\n";
        } else {
            store.sortById(choice == SORT_BY_ID_ASC);
            std::cout << "[THANH CONG] Da sap xep danh sach theo ma hop dong!\n";
        }
    } catch (const std::exception& e) {
        std::cout << "[LOI] Khong the luu thu tu sap xep: " << e.what() << "\n";
    }
    xemDanhSach();
}

//cap nhat thong tin hop dong
void HopDongMenu::capNhatHopDong() {
    std::cout << "\n>>> CAP NHAT THONG TIN HOP DONG <<<\n";
    std::string id = InputHelper::getString("Nhap Ma hop dong can cap nhat: ", false);
    if (std::cin.eof()) return;
    id = Normalized::toUpper(Normalized::trim(id));
    HopDong* hd = store.findById(id);
    if (hd == nullptr) {
        std::cout << "[LOI] Khong tim thay hop dong co ma: " << id << "\n";
        InputHelper::pause();
        return;
    }

    std::cout << "\nThong tin hien tai cua hop dong:\n";
    hd->displayDetail();
    HopDong updated = *hd;

    std::cout << "\nChon thong tin can cap nhat:\n"
              << "  [" << UPDATE_PACKAGE << "] Doi goi cuoc\n"
              << "  [" << UPDATE_EXPIRY << "] Gia han ngay het han\n"
              << "  [" << UPDATE_STATUS << "] Chuyen trang thai (HieuLuc / TamDung / ThanhLy)\n"
              << "  [" << UPDATE_CANCEL << "] Huy bo thao tac\n";
    int choice = InputHelper::getInt("Nhap lua chon [0-3]: ", UPDATE_CANCEL, UPDATE_STATUS);

    if (choice == UPDATE_CANCEL || std::cin.eof()) {
        std::cout << "[DA HUY] Thao tac cap nhat da duoc huy bo.\n";
        InputHelper::pause();
        return;
    }

    try {
        if (choice == UPDATE_PACKAGE) {
            std::string maGoiMoi = InputHelper::getString("Nhap Ma goi cuoc moi: ", false);
            if (std::cin.eof()) return;
            maGoiMoi = Normalized::toUpper(Normalized::trim(maGoiMoi));
            if (goiCuocStore.findById(maGoiMoi) == nullptr) {
                std::cout << "  [!] Ma goi cuoc '" << maGoiMoi << "' khong ton tai trong he thong!\n";
                InputHelper::pause();
                return;
            }
            double giaMoi = InputHelper::getDouble("Nhap Gia tri goi moi (VND): ", 0.0);
            if (std::cin.eof()) return;
            updated.setMaGoiCuoc(maGoiMoi);
            updated.setGiaTriGoi(giaMoi);
            store.update(id, updated);
            std::cout << "[THANH CONG] Da cap nhat goi cuoc moi cho hop dong " << id << "!\n";
        } else if (choice == UPDATE_EXPIRY) {
            std::string ngayHHStr = InputHelper::getString("Nhap Ngay het han moi (DD/MM/YYYY, 'now' hoac '0' de huy): ", false);
            if (ngayHHStr == "0" || std::cin.eof()) {
                std::cout << "[DA HUY] Thao tac gia han da duoc huy bo.\n";
                InputHelper::pause();
                return;
            }
            Date ngayHHMoi;
            try {
                ngayHHMoi = Date::parse(ngayHHStr);
            } catch (const std::exception& e) {
                std::cout << "[LOI] " << e.what() << "\n";
                InputHelper::pause();
                return;
            }
            updated.giaHan(ngayHHMoi);
            store.update(id, updated);
            std::cout << "[THANH CONG] Da gia han hop dong " << id << " den ngay " << ngayHHMoi.toString() << "!\n";
        } else if (choice == UPDATE_STATUS) {
            std::cout << "Chon trang thai moi:\n"
                      << "  [" << STATUS_CHOICE_ACTIVE << "] " << HopDongConstants::STATUS_ACTIVE << "\n"
                      << "  [" << STATUS_CHOICE_SUSPENDED << "] " << HopDongConstants::STATUS_SUSPENDED << "\n"
                      << "  [" << STATUS_CHOICE_TERMINATED << "] " << HopDongConstants::STATUS_TERMINATED << "\n";
            int sChoice = InputHelper::getInt("Nhap lua chon [1-3]: ", STATUS_CHOICE_ACTIVE, STATUS_CHOICE_TERMINATED);
            if (std::cin.eof()) return;
            if (sChoice == STATUS_CHOICE_ACTIVE) updated.kichHoatLai();
            else if (sChoice == STATUS_CHOICE_SUSPENDED) updated.tamDung();
            else if (sChoice == STATUS_CHOICE_TERMINATED) updated.chamDut();

            store.update(id, updated);
            std::cout << "[THANH CONG] Da cap nhat trang thai thanh: " << updated.getTrangThai() << "!\n";
        }
    } catch (const AppException& e) {
        std::cout << "[LOI] " << e.what() << "\n";
    }
    InputHelper::pause();
}

//xoa hop dong khoi he thong
void HopDongMenu::xoaHopDong() {
    std::cout << "\n>>> XOA / THANH LY HOP DONG <<<\n";
    std::string id = InputHelper::getString("Nhap Ma hop dong can xoa: ", false);
    if (std::cin.eof()) return;
    id = Normalized::toUpper(Normalized::trim(id));
    HopDong* hd = store.findById(id);
    if (hd == nullptr) {
        std::cout << "[LOI] Khong tim thay hop dong co ma: " << id << "\n";
        InputHelper::pause();
        return;
    }

    std::cout << "\nThong tin hop dong can xoa:\n";
    hd->displayDetail();

    bool confirm = InputHelper::getConfirm("Ban co chac chan muon xoa hop dong nay khoi he thong?");
    if (std::cin.eof()) return;
    if (confirm) {
        try {
            store.remove(id);
            std::cout << "[THANH CONG] Da xoa hop dong " << id << " khoi he thong va cap nhat file!\n";
        } catch (const AppException& e) {
            std::cout << "[LOI] " << e.what() << "\n";
        }
    } else {
        std::cout << "[DA HUY] Thao tac xoa da duoc huy bo.\n";
    }
    InputHelper::pause();
}
